export const environment = {
  production: true,
  // api_url: "http://3.16.131.123:3000",
//  api_url:"http://localhost:3000",
  api_url:" https://api-wediina.herokuapp.com",
  venue_id:null,
  vendor_id:null,
  customer_id:null,
  city:String,
  vemail:String
};
