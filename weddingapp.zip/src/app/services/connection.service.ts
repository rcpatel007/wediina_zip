import { Injectable } from '@angular/core';
import { Http, Headers } from '@angular/http';
import { map } from 'rxjs/operators';
import { environment } from '../../environments/environment';


@Injectable({
  providedIn: 'root'
})
export class ConnectionService {

  constructor(private http: Http) { }


  //  imgur API

  imgurImage(base64) {
    let headers = new Headers({ 'Authorization': 'Client-ID e22c18840a29adc' });
    headers.append('Accept', 'application/json');
    return this.http.post('https://api.imgur.com/3/image', base64, { headers: headers })
      .pipe(map(res => res.json()));


  }

  imgurotherImage(otherbase64) {
    let headers = new Headers({ 'Authorization': 'Client-ID e22c18840a29adc' });
    headers.append('Accept', 'application/json');
    // headers.append('authorization', 'e22c18840a29adc');
    return this.http.post('https://api.imgur.com/3/image', otherbase64, { headers: headers })
      .pipe(map(res => res.json()));

  }

  // home ads

  getHomeads() {
    //  headers = new Headers();  
    let headers = new Headers;
    headers.append('Access-Control-Allow-Origin',' *');
    headers.append('Access-Control-Allow-Methods',' GET, POST, PATCH, PUT, DELETE, OPTIONS,get,put,post,delete,options');
    headers.append('Access-Control-Allow-Headers','Origin, Content-Type');  
    return this.http.get(environment.api_url + '/home_ads', { headers: headers })
      .pipe(map(res => res.json()));

  }

  // home slider image

  gethomeslider() {
    let headers = new Headers;
    headers.append('Access-Control-Allow-Origin',' *');
    headers.append('Access-Control-Allow-Methods',' GET, POST, PATCH, PUT, DELETE, OPTIONS,get,put,post,delete,options');
    headers.append('Access-Control-Allow-Headers','Origin, Content-Type');
    //  headers = new Headers();    
    return this.http.get(environment.api_url + '/home_slider', { headers: headers })
      .pipe(map(res => res.json()));

  }

  /******************************** */
  // venue


  venueLogin(venue_login) {
    let headers = new Headers;
    headers.append('Access-Control-Allow-Origin',' *');
    headers.append('Access-Control-Allow-Methods',' GET, POST, PATCH, PUT, DELETE, OPTIONS,get,put,post,delete,options');
    headers.append('Access-Control-Allow-Headers','Origin, Content-Type');
    // let headers = new Headers();
    return this.http.post(environment.api_url + '/venueLogin/, { headers: headers }', venue_login)
      .pipe(map(res => res.json()));

  }

  getVenueCategory() {
    let headers = new Headers;
    headers.append('Access-Control-Allow-Origin',' *');
    headers.append('Access-Control-Allow-Methods',' GET, POST, PATCH, PUT, DELETE, OPTIONS,get,put,post,delete,options');
    headers.append('Access-Control-Allow-Headers','Origin, Content-Type');
    //  headers = new Headers();    
    return this.http.get(environment.api_url + '/venue_cat', { headers: headers })
      .pipe(map(res => res.json()));

  }

  // get Product by id

  getVenueCategoryById(id) {
    let headers = new Headers;
    headers.append('Access-Control-Allow-Origin',' *');
    headers.append('Access-Control-Allow-Methods',' GET, POST, PATCH, PUT, DELETE, OPTIONS,get,put,post,delete,options');
    headers.append('Access-Control-Allow-Headers','Origin, Content-Type');
    //  headers = new Headers();    
    return this.http.get(environment.api_url + '/venue_cat/, { headers: headers }' + id)
      .pipe(map(res => res.json()));

  }

  getVenueByCategoryId(id) {
    //  headers = new Headers();    
    let headers = new Headers;
    headers.append('Access-Control-Allow-Origin',' *');
    headers.append('Access-Control-Allow-Methods',' GET, POST, PATCH, PUT, DELETE, OPTIONS,get,put,post,delete,options');
    headers.append('Access-Control-Allow-Headers','Origin, Content-Type');
    return this.http.get(environment.api_url + '/venue_by_cat_id/, { headers: headers }' + id)
      .pipe(map(res => res.json()));

  }


  getVenues() {
    //  headers = new Headers();    
    let headers = new Headers;
    headers.append('Access-Control-Allow-Origin',' *');
    headers.append('Access-Control-Allow-Methods',' GET, POST, PATCH, PUT, DELETE, OPTIONS,get,put,post,delete,options');
    headers.append('Access-Control-Allow-Headers','Origin, Content-Type');
    return this.http.get(environment.api_url + '/venue', { headers: headers })
      .pipe(map(res => res.json()));

  }

  sendsms(sms,mobileno) {
    let headers = new Headers;
    headers.append('Access-Control-Allow-Origin',' *');
    headers.append('Access-Control-Allow-Methods',' GET, POST, PATCH, PUT, DELETE, OPTIONS,get,put,post,delete,options');
    headers.append('Access-Control-Allow-Headers','Origin, Content-Type'); 
  return this.http.get("https://login.bulksmsgateway.in/sendmessage.php?user=globalbits&password=1249566&mobile="+mobileno+"&message="+sms+"&sender=WEDINA&type=3",{headers:headers})
    .pipe(map(res => res.json()));

  }
  // return this.http.get("http://5.9.69.238/api/sendSMS.php?user=CHIRAG&password=123456&sender=WEDINA&dest="+mobileno+"&apid=9078&text="+sms+"&dcs=0",{headers:headers})

  // sendsms(sms,mobileno) {
  //   //  headers = new Headers();    
  //   return this.http.get("http://5.9.0.178:8000/Sendsms?user=CHIRAG&password=123456&sender=WEDINA&dest=91"+mobileno+"&apid=9078&text="+sms+"&dcs=0")
  //     .pipe(map(res => res.json()));

  // }
  // get Product by id

  getVenueById(id) {
    let headers = new Headers;
    headers.append('Access-Control-Allow-Origin',' *');
    headers.append('Access-Control-Allow-Methods',' GET, POST, PATCH, PUT, DELETE, OPTIONS,get,put,post,delete,options');
    headers.append('Access-Control-Allow-Headers','Origin, Content-Type');
    //  headers = new Headers();    
    return this.http.get(environment.api_url + '/venue_by_id/, { headers: headers }' + id)
      .pipe(map(res => res.json()));

  }

  getVenuecatById(id) {
    let headers = new Headers;
    headers.append('Access-Control-Allow-Origin',' *');
    headers.append('Access-Control-Allow-Methods',' GET, POST, PATCH, PUT, DELETE, OPTIONS,get,put,post,delete,options');
    headers.append('Access-Control-Allow-Headers','Origin, Content-Type');
    //  headers = new Headers();    
    return this.http.get(environment.api_url + '/venue_by_cat_id/, { headers: headers }' + id)
      .pipe(map(res => res.json()));

  }

  // add product

  addVenue(venue) {
    let headers = new Headers;
    headers.append('Access-Control-Allow-Origin',' *');
    headers.append('Access-Control-Allow-Methods',' GET, POST, PATCH, PUT, DELETE, OPTIONS,get,put,post,delete,options');
    headers.append('Access-Control-Allow-Headers','Origin, Content-Type');
    return this.http.post(environment.api_url + '/newvenue/, { headers: headers }', venue)
      .pipe(map(res => res.json()));

  }
  

  // edit product

  editVenue(id, updateVenue) {
    let headers = new Headers;
    headers.append('Access-Control-Allow-Origin',' *');
    headers.append('Access-Control-Allow-Methods',' GET, POST, PATCH, PUT, DELETE, OPTIONS,get,put,post,delete,options');
    headers.append('Access-Control-Allow-Headers','Origin, Content-Type');
    return this.http.put(environment.api_url + '/venue_update/, { headers: headers }' + id, updateVenue)
      .pipe(map(res => res.json()));

  }


  venueBookindDate(id, updatedate) {
    let headers = new Headers;
    headers.append('Access-Control-Allow-Origin',' *');
    headers.append('Access-Control-Allow-Methods',' GET, POST, PATCH, PUT, DELETE, OPTIONS,get,put,post,delete,options');
    headers.append('Access-Control-Allow-Headers','Origin, Content-Type');
    return this.http.put(environment.api_url + '/venue_bookdate/, { headers: headers }' + id, updatedate)
      .pipe(map(res => res.json()));

  }


  venueInquiry(vinquiry) {
    let headers = new Headers;
    headers.append('Access-Control-Allow-Origin',' *');
    headers.append('Access-Control-Allow-Methods',' GET, POST, PATCH, PUT, DELETE, OPTIONS,get,put,post,delete,options');
    headers.append('Access-Control-Allow-Headers','Origin, Content-Type');
    return this.http.post(environment.api_url + '/venue_inquiry', { headers: headers }, vinquiry)
      .pipe(map(res => res.json()));

  }
  getVenueInquiryById(id) {
    let headers = new Headers;
    headers.append('Access-Control-Allow-Origin',' *');
    headers.append('Access-Control-Allow-Methods',' GET, POST, PATCH, PUT, DELETE, OPTIONS,get,put,post,delete,options');
    headers.append('Access-Control-Allow-Headers','Origin, Content-Type');
    //  headers = new Headers();    
    return this.http.get(environment.api_url + '/venue_inquiry/, { headers: headers }' + id)
      .pipe(map(res => res.json()));

  }
  getvenueInquiry() {
    let headers = new Headers;
    headers.append('Access-Control-Allow-Origin',' *');
    headers.append('Access-Control-Allow-Methods',' GET, POST, PATCH, PUT, DELETE, OPTIONS,get,put,post,delete,options');
    headers.append('Access-Control-Allow-Headers','Origin, Content-Type');
    //  headers = new Headers();    
    return this.http.get(environment.api_url + '/venue_inquiry', { headers: headers })
      .pipe(map(res => res.json()));

  }
  
  getvendorInquiry() {
    let headers = new Headers;
    headers.append('Access-Control-Allow-Origin',' *');
    headers.append('Access-Control-Allow-Methods',' GET, POST, PATCH, PUT, DELETE, OPTIONS,get,put,post,delete,options');
    headers.append('Access-Control-Allow-Headers','Origin, Content-Type');
    //  headers = new Headers();    
    return this.http.get(environment.api_url + '/vendor_inquiry', { headers: headers })
      .pipe(map(res => res.json()));

  }


 /* get img by id */
 editvenueimg(updateimg) {
  let headers = new Headers;
  headers.append('Access-Control-Allow-Origin',' *');
  headers.append('Access-Control-Allow-Methods',' GET, POST, PATCH, PUT, DELETE, OPTIONS,get,put,post,delete,options');
  headers.append('Access-Control-Allow-Headers','Origin, Content-Type');
  return this.http.put(environment.api_url + '/venue_update_image/, { headers: headers }'+updateimg._id, updateimg)
  .pipe(map( res => res.json()));


}
 /* get other img by id */
 othereditvenueimg(otherupdateimg) {
  let headers = new Headers;
  headers.append('Access-Control-Allow-Origin',' *');
  headers.append('Access-Control-Allow-Methods',' GET, POST, PATCH, PUT, DELETE, OPTIONS,get,put,post,delete,options');
  headers.append('Access-Control-Allow-Headers','Origin, Content-Type');
  return this.http.put(environment.api_url + '/venue_update_otherimage/, { headers: headers }'+otherupdateimg._id, otherupdateimg)
  .pipe(map( res => res.json()));
}





  /* get img by id */
 editimg(updateimg) {
  let headers = new Headers;
  headers.append('Access-Control-Allow-Origin',' *');
  headers.append('Access-Control-Allow-Methods',' GET, POST, PATCH, PUT, DELETE, OPTIONS,get,put,post,delete,options');
  headers.append('Access-Control-Allow-Headers','Origin, Content-Type');
  return this.http.put(environment.api_url + '/Vendor_update_image/, { headers: headers }'+updateimg._id, updateimg)
  .pipe(map( res => res.json()));
}

 /* get other img by id */
 othereditimg(otherupdateimg) {
  let headers = new Headers;
  headers.append('Access-Control-Allow-Origin',' *');
  headers.append('Access-Control-Allow-Methods',' GET, POST, PATCH, PUT, DELETE, OPTIONS,get,put,post,delete,options');
  headers.append('Access-Control-Allow-Headers','Origin, Content-Type');
  return this.http.put(environment.api_url + '/vendor_update_otherimage/, { headers: headers }'+otherupdateimg._id, otherupdateimg)
  .pipe(map( res => res.json()));
}
  /******************************************************* */

  // vendor


  vendorLogin(vendor) {
    let headers = new Headers;
    headers.append('Access-Control-Allow-Origin',' *');
    headers.append('Access-Control-Allow-Methods',' GET, POST, PATCH, PUT, DELETE, OPTIONS,get,put,post,delete,options');
    headers.append('Access-Control-Allow-Headers','Origin, Content-Type');
    return this.http.post(environment.api_url + '/vendorLogin', { headers: headers }, vendor)
      .pipe(map(res => res.json()));

  }
  getVendorCategory() {
    let headers = new Headers;
    headers.append('Access-Control-Allow-Origin',' *');
    headers.append('Access-Control-Allow-Methods',' GET, POST, PATCH, PUT, DELETE, OPTIONS,get,put,post,delete,options');
    headers.append('Access-Control-Allow-Headers','Origin, Content-Type');
    //  headers = new Headers();    
    return this.http.get(environment.api_url + '/vendor_cat', { headers: headers })
      .pipe(map(res => res.json()));

  }
  getVendorcatById(id) {
    let headers = new Headers;
    headers.append('Access-Control-Allow-Origin',' *');
    headers.append('Access-Control-Allow-Methods',' GET, POST, PATCH, PUT, DELETE, OPTIONS,get,put,post,delete,options');
    headers.append('Access-Control-Allow-Headers','Origin, Content-Type');
    //  headers = new Headers();    
    return this.http.get(environment.api_url + '/vendor_by_cat_id/, { headers: headers }' + id)
      .pipe(map(res => res.json()));
  }

  // get Product by id

  getVendorCategoryById(id) {
    let headers = new Headers;
    headers.append('Access-Control-Allow-Origin',' *');
    headers.append('Access-Control-Allow-Methods',' GET, POST, PATCH, PUT, DELETE, OPTIONS,get,put,post,delete,options');
    headers.append('Access-Control-Allow-Headers','Origin, Content-Type');
    //  headers = new Headers();    
    return this.http.get(environment.api_url + '/vendor_cat/, { headers: headers }' + id)
      .pipe(map(res => res.json()));

  }


  getVendors() {
    let headers = new Headers;
    headers.append('Access-Control-Allow-Origin',' *');
    headers.append('Access-Control-Allow-Methods',' GET, POST, PATCH, PUT, DELETE, OPTIONS,get,put,post,delete,options');
    headers.append('Access-Control-Allow-Headers','Origin, Content-Type');
    //  headers = new Headers();    
    return this.http.get(environment.api_url + '/vendor', { headers: headers })
      .pipe(map(res => res.json()));

  }

  // get Product by id

  getVendorById(id) {
    let headers = new Headers;
    headers.append('Access-Control-Allow-Origin',' *');
    headers.append('Access-Control-Allow-Methods',' GET, POST, PATCH, PUT, DELETE, OPTIONS,get,put,post,delete,options');
    headers.append('Access-Control-Allow-Headers','Origin, Content-Type');
    //  headers = new Headers();    
    return this.http.get(environment.api_url + '/vendor_by_id/, { headers: headers }' + id)
      .pipe(map(res => res.json()));

  }

  // add product

  addVendor(vendor) {
    let headers = new Headers;
    headers.append('Access-Control-Allow-Origin',' *');
    headers.append('Access-Control-Allow-Methods',' GET, POST, PATCH, PUT, DELETE, OPTIONS,get,put,post,delete,options');
    headers.append('Access-Control-Allow-Headers','Origin, Content-Type');
    return this.http.post(environment.api_url + '/newVendor/, { headers: headers }', vendor)
      .pipe(map(res => res.json()));

  }

  vendorInquiry(vinquiry) {
    let headers = new Headers;
    headers.append('Access-Control-Allow-Origin',' *');
    headers.append('Access-Control-Allow-Methods',' GET, POST, PATCH, PUT, DELETE, OPTIONS,get,put,post,delete,options');
    headers.append('Access-Control-Allow-Headers','Origin, Content-Type');
    return this.http.post(environment.api_url + '/vendor_inquiry/, { headers: headers }', vinquiry)
      .pipe(map(res => res.json()));


  }


  getVendorInquiryById(id) {
    let headers = new Headers;
    headers.append('Access-Control-Allow-Origin',' *');
    headers.append('Access-Control-Allow-Methods',' GET, POST, PATCH, PUT, DELETE, OPTIONS,get,put,post,delete,options');
    headers.append('Access-Control-Allow-Headers','Origin, Content-Type');
    //  headers = new Headers();    
    return this.http.get(environment.api_url + '/vendor_inquiry/, { headers: headers }' + id)
      .pipe(map(res => res.json()));

  }


  editVendor(id, updateVendor) {
    let headers = new Headers;
    headers.append('Access-Control-Allow-Origin',' *');
    headers.append('Access-Control-Allow-Methods',' GET, POST, PATCH, PUT, DELETE, OPTIONS,get,put,post,delete,options');
    headers.append('Access-Control-Allow-Headers','Origin, Content-Type');
    return this.http.put(environment.api_url + '/vendor_update/, { headers: headers }' + id, updateVendor)
      .pipe(map(res => res.json()));

  }

  validatecustomerpwd(id, validate_pwd) {
    //  headers = new Headers();  
    let headers = new Headers;
    headers.append('Access-Control-Allow-Origin',' *');
    headers.append('Access-Control-Allow-Methods',' GET, POST, PATCH, PUT, DELETE, OPTIONS,get,put,post,delete,options');
    headers.append('Access-Control-Allow-Headers','Origin, Content-Type');
    return this.http.put(environment.api_url + '/validate_customer_password/, { headers: headers }' + id, validate_pwd)
      .pipe(map(res => res.json()));
  }

  updatecustomerpwd(id, pwd) {
    let headers = new Headers;
    headers.append('Access-Control-Allow-Origin',' *');
    headers.append('Access-Control-Allow-Methods',' GET, POST, PATCH, PUT, DELETE, OPTIONS,get,put,post,delete,options');
    headers.append('Access-Control-Allow-Headers','Origin, Content-Type');
    //  headers = new Headers();  
    return this.http.put(environment.api_url + '/update_customer_password/, { headers: headers }' + id, pwd)
      .pipe(map(res => res.json()));
  }



  validatevenuepwd(id, validate_pwd) {
    let headers = new Headers;
    headers.append('Access-Control-Allow-Origin',' *');
    headers.append('Access-Control-Allow-Methods',' GET, POST, PATCH, PUT, DELETE, OPTIONS,get,put,post,delete,options');
    headers.append('Access-Control-Allow-Headers','Origin, Content-Type');
    //  headers = new Headers();  
    return this.http.put(environment.api_url + '/validate_venue_password/, { headers: headers }' + id, validate_pwd)
      .pipe(map(res => res.json()));
  }

  updatevenuepwd(id, upwd) {
    //  headers = new Headers();  
    return this.http.put(environment.api_url + '/venue_pwd_update/, { headers: headers }' + id, upwd)
      .pipe(map(res => res.json()));
  }


  validatevendorpwd(id, validate_pwd) {
    let headers = new Headers;
    headers.append('Access-Control-Allow-Origin',' *');
    headers.append('Access-Control-Allow-Methods',' GET, POST, PATCH, PUT, DELETE, OPTIONS,get,put,post,delete,options');
    headers.append('Access-Control-Allow-Headers','Origin, Content-Type');
    //  headers = new Headers();  
    return this.http.put(environment.api_url + '/validate_vendor_password/, { headers: headers }' + id, validate_pwd)
      .pipe(map(res => res.json()));
  }

  updatevendorpwd(id, pwd) {
    let headers = new Headers;
    headers.append('Access-Control-Allow-Origin',' *');
    headers.append('Access-Control-Allow-Methods',' GET, POST, PATCH, PUT, DELETE, OPTIONS,get,put,post,delete,options');
    headers.append('Access-Control-Allow-Headers','Origin, Content-Type');
    //  headers = new Headers();  
    return this.http.put(environment.api_url + '/vendors_pwd_update/, { headers: headers }' + id, pwd)
      .pipe(map(res => res.json()));
  }



  forgetVendor(mail) {
    let headers = new Headers;
    headers.append('Access-Control-Allow-Origin',' *');
    headers.append('Access-Control-Allow-Methods',' GET, POST, PATCH, PUT, DELETE, OPTIONS,get,put,post,delete,options');
    headers.append('Access-Control-Allow-Headers','Origin, Content-Type');
    return this.http.put(environment.api_url + '/forgot_vendor_password/, { headers: headers }', mail)
      .pipe(map(res => res.json()));

  }


  forgetVenue(mail) {
    let headers = new Headers;
    headers.append('Access-Control-Allow-Origin',' *');
    headers.append('Access-Control-Allow-Methods',' GET, POST, PATCH, PUT, DELETE, OPTIONS,get,put,post,delete,options');
    headers.append('Access-Control-Allow-Headers','Origin, Content-Type');
    return this.http.put(environment.api_url + '/forgot_venue_password/, { headers: headers }', mail)
      .pipe(map(res => res.json()));

  }

  forgetCustomer(mail) {
    let headers = new Headers;
    headers.append('Access-Control-Allow-Origin',' *');
    headers.append('Access-Control-Allow-Methods',' GET, POST, PATCH, PUT, DELETE, OPTIONS,get,put,post,delete,options');
    headers.append('Access-Control-Allow-Headers','Origin, Content-Type');
    return this.http.put(environment.api_url + '/forgot_customer_password/, { headers: headers }', mail)
      .pipe(map(res => res.json()));

  }
  vendorBookindDate(id, updatedate) {
    let headers = new Headers;
    headers.append('Access-Control-Allow-Origin',' *');
    headers.append('Access-Control-Allow-Methods',' GET, POST, PATCH, PUT, DELETE, OPTIONS,get,put,post,delete,options');
    headers.append('Access-Control-Allow-Headers','Origin, Content-Type');
    return this.http.put(environment.api_url + '/vendor_bookdate/, { headers: headers }' + id, updatedate)
      .pipe(map(res => res.json()));

  }


  // ***********************************************************
  // Customer
  // **************************************************************


  addcustomer(customer) {
    let headers = new Headers;
    headers.append('Access-Control-Allow-Origin',' *');
    headers.append('Access-Control-Allow-Methods',' GET, POST, PATCH, PUT, DELETE, OPTIONS,get,put,post,delete,options');
    headers.append('Access-Control-Allow-Headers','Origin, Content-Type');
    return this.http.post(environment.api_url + '/new_customer/, { headers: headers }', customer)
      .pipe(map(res => res.json()));

  }



  customerLogin(customer) {
    let headers = new Headers;
    headers.append('Access-Control-Allow-Origin',' *');
    headers.append('Access-Control-Allow-Methods',' GET, POST, PATCH, PUT, DELETE, OPTIONS,get,put,post,delete,options');
    headers.append('Access-Control-Allow-Headers','Origin, Content-Type');
    //  headers.append('Access-Control-Allow-Origin',' *');
    // headers.append('Access-Control-Allow-Methods',' GET, POST, PATCH, PUT, DELETE, OPTIONS,get,put,post,delete,options');
    // headers.append('Access-Control-Allow-Headers','Origin, Content-Type, X-Auth-Token');
    return this.http.post(environment.api_url + '/customerLogin/, { headers: headers }', customer)
      .pipe(map(res => res.json()));

  }


  getCustomerById(id) {
    let headers = new Headers;
    headers.append('Access-Control-Allow-Origin',' *');
    headers.append('Access-Control-Allow-Methods',' GET, POST, PATCH, PUT, DELETE, OPTIONS,get,put,post,delete,options');
    headers.append('Access-Control-Allow-Headers','Origin, Content-Type');
    //  headers = new Headers();    
    return this.http.get(environment.api_url + '/customer/, { headers: headers }' + id)
      .pipe(map(res => res.json()));

  }

  getCustomer() {
    let headers = new Headers;
    headers.append('Access-Control-Allow-Origin',' *');
    headers.append('Access-Control-Allow-Methods',' GET, POST, PATCH, PUT, DELETE, OPTIONS,get,put,post,delete,options');
    headers.append('Access-Control-Allow-Headers','Origin, Content-Type');
    //  headers = new Headers();    
    return this.http.get(environment.api_url + '/customer', { headers: headers })
      .pipe(map(res => res.json()));

  }

  // add product

  // edit product

  editCustomer(id, updateVenue) {
    let headers = new Headers;
    headers.append('Access-Control-Allow-Origin',' *');
    headers.append('Access-Control-Allow-Methods',' GET, POST, PATCH, PUT, DELETE, OPTIONS,get,put,post,delete,options');
    headers.append('Access-Control-Allow-Headers','Origin, Content-Type');
    return this.http.put(environment.api_url + '/customer/, { headers: headers }' + id, updateVenue)
      .pipe(map(res => res.json()));

  }
  /*********************************************************************** */
  // review
  /********************************************************** */

  getads() {
    let headers = new Headers;
    headers.append('Access-Control-Allow-Origin',' *');
    headers.append('Access-Control-Allow-Methods',' GET, POST, PATCH, PUT, DELETE, OPTIONS,get,put,post,delete,options');
    headers.append('Access-Control-Allow-Headers','Origin, Content-Type');
    //  headers = new Headers();    
    return this.http.get(environment.api_url + '/ads_image', { headers: headers })
      .pipe(map(res => res.json()));

  }


  getreviewById(id) {
    let headers = new Headers;
    headers.append('Access-Control-Allow-Origin',' *');
    headers.append('Access-Control-Allow-Methods',' GET, POST, PATCH, PUT, DELETE, OPTIONS,get,put,post,delete,options');
    headers.append('Access-Control-Allow-Headers','Origin, Content-Type');
    //  headers = new Headers();    
    return this.http.get(environment.api_url + '/review/, { headers: headers }' + id)
      .pipe(map(res => res.json()));

  }


  getreview() {
    let headers = new Headers;
    headers.append('Access-Control-Allow-Origin',' *');
    headers.append('Access-Control-Allow-Methods',' GET, POST, PATCH, PUT, DELETE, OPTIONS,get,put,post,delete,options');
    headers.append('Access-Control-Allow-Headers','Origin, Content-Type');
    //  headers = new Headers();    
    return this.http.get(environment.api_url + '/review', { headers: headers })
      .pipe(map(res => res.json()));

  }

  // get Product by id

  getreviewId(id) {
    let headers = new Headers;
    headers.append('Access-Control-Allow-Origin',' *');
    headers.append('Access-Control-Allow-Methods',' GET, POST, PATCH, PUT, DELETE, OPTIONS,get,put,post,delete,options');
    headers.append('Access-Control-Allow-Headers','Origin, Content-Type');
    //  headers = new Headers();    
    return this.http.get(environment.api_url + '/review/, { headers: headers }' + id)
      .pipe(map(res => res.json()));

  }

  // add product

  addreview(review) {
    let headers = new Headers;
    headers.append('Access-Control-Allow-Origin',' *');
    headers.append('Access-Control-Allow-Methods',' GET, POST, PATCH, PUT, DELETE, OPTIONS,get,put,post,delete,options');
    headers.append('Access-Control-Allow-Headers','Origin, Content-Type');
    // let headers = new Headers;
    //  headers.append('Access-Control-Allow-Origin',' *');
    // headers.append('Access-Control-Allow-Methods',' GET, POST, PATCH, PUT, DELETE, OPTIONS,get,put,post,delete,options');
    // headers.append('Access-Control-Allow-Headers','Origin, Content-Type, X-Auth-Token'); 
    return this.http.post(environment.api_url + '/review', { headers: headers }, review)
      .pipe(map(res => res.json()));

  }

  addcontact(contact) {
    let headers = new Headers;
    headers.append('Access-Control-Allow-Origin',' *');
    headers.append('Access-Control-Allow-Methods',' GET, POST, PATCH, PUT, DELETE, OPTIONS,get,put,post,delete,options');
    headers.append('Access-Control-Allow-Headers','Origin, Content-Type');
    // let headers = new Headers;
    //  headers.append('Access-Control-Allow-Origin',' *');
    // headers.append('Access-Control-Allow-Methods',' GET, POST, PATCH, PUT, DELETE, OPTIONS,get,put,post,delete,options');
    // headers.append('Access-Control-Allow-Headers','Origin, Content-Type, X-Auth-Token'); 
    return this.http.post(environment.api_url + '/contact_detail', { headers: headers }, contact)
      .pipe(map(res => res.json()));

  }

  getcity() {
    let headers = new Headers;
    headers.append('Access-Control-Allow-Origin',' *');
    headers.append('Access-Control-Allow-Methods',' GET, POST, PATCH, PUT, DELETE, OPTIONS,get,put,post,delete,options');
    headers.append('Access-Control-Allow-Headers','Origin, Content-Type');
    //  headers = new Headers();    
    return this.http.get(environment.api_url + '/city', { headers: headers })
      .pipe(map(res => res.json()));
  }
}
