import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-venuelogin',
  templateUrl: './venuelogin.component.html',
  styleUrls: ['./venuelogin.component.css']
})
export class VenueloginComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
